<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Registration */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="registration-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'clientNo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'branchNo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'staffNo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'dateJoined')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
