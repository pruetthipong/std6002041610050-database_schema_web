<?php
    namespace frontend\models;
    class Branch extends \common\models\Branch{}
?>