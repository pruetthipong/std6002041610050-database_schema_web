<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%propertyforrent}}`.
 */
class m190501_154011_create_propertyforrent_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%propertyforrent}}', [
            'id' => $this->primaryKey(),
            'propertyNo'=>$this->string(200),
            'street'=>$this->string(200),
            'city'=>$this->string(200),
            'postcode'=>$this->string(200),
            'type'=>$this->string(200),
            'room'=>$this->string(200),
            'rent'=>$this->string(200),
            'ownerNo'=>$this->string(200),
            'staffNo'=>$this->string(200),
            'branchNo'=>$this->string(200)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%propertyforrent}}');
    }
}
