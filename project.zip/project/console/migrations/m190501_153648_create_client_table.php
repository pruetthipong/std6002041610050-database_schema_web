<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%client}}`.
 */
class m190501_153648_create_client_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%client}}', [
            'id' => $this->primaryKey(),
            'cientNo'=>$this->string(200),
            'fname'=>$this->string(200),
            'lname'=>$this->string(200),
            'telNo'=>$this->string(200),
            'perftype'=>$this->string(200),
            'maxRent'=>$this->string(200)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%client}}');
    }
}
