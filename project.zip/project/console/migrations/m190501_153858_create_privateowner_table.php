<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%privateowner}}`.
 */
class m190501_153858_create_privateowner_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%privateowner}}', [
            'id' => $this->primaryKey(),
            'ownerNo'=>$this->string(200),
            'fname'=>$this->string(200),
            'lname'=>$this->string(200),
            'address'=>$this->string(200),
            'telNo'=>$this->string(200)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%privateowner}}');
    }
}
