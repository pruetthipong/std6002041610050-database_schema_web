<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%staff}}`.
 */
class m190501_154309_create_staff_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%staff}}', [
            'id' => $this->primaryKey(),
            'staffNo' => $this->string(200),
            'fName'=>$this->string(200),
            'lName'=>$this->string(200),
            'position'=>$this->string(200),
            'sex'=>$this->string(200),
            'DOB'=>$this->string(200),
            'salary'=>$this->string(200),
            'branchNo'=>$this->string(200)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%staff}}');
    }
}
