<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Propertyforrent".
 *
 * @property int $id
 * @property string $propertyNo
 * @property string $street
 * @property string $city
 * @property string $postcode
 * @property string $type
 * @property string $room
 * @property string $rent
 * @property string $ownerNo
 * @property string $staffNo
 * @property string $branchNo
 */
class Propertyforrent extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Propertyforrent';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['propertyNo', 'street', 'city', 'postcode', 'type', 'room', 'rent', 'ownerNo', 'staffNo', 'branchNo'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'propertyNo' => 'Property No',
            'street' => 'Street',
            'city' => 'City',
            'postcode' => 'Postcode',
            'type' => 'Type',
            'room' => 'Room',
            'rent' => 'Rent',
            'ownerNo' => 'Owner No',
            'staffNo' => 'Staff No',
            'branchNo' => 'Branch No',
        ];
    }
}
