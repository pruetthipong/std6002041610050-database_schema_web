<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Branch".
 *
 * @property int $id
 * @property string $street
 * @property string $city
 * @property string $postcode
 */
class Branch extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Branch';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['street', 'city', 'postcode'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'street' => 'Street',
            'city' => 'City',
            'postcode' => 'Postcode',
        ];
    }
}
