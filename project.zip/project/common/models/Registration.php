<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Registration".
 *
 * @property int $id
 * @property string $clientNo
 * @property string $branchNo
 * @property string $staffNo
 * @property string $dateJoined
 */
class Registration extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Registration';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['clientNo', 'branchNo', 'staffNo', 'dateJoined'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'clientNo' => 'Client No',
            'branchNo' => 'Branch No',
            'staffNo' => 'Staff No',
            'dateJoined' => 'Date Joined',
        ];
    }
}
