<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Client".
 *
 * @property int $id
 * @property string $cientNo
 * @property string $fname
 * @property string $lname
 * @property string $telNo
 * @property string $perftype
 * @property string $maxRent
 */
class Client extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Client';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cientNo', 'fname', 'lname', 'telNo', 'perftype', 'maxRent'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cientNo' => 'Cient No',
            'fname' => 'Fname',
            'lname' => 'Lname',
            'telNo' => 'Tel No',
            'perftype' => 'Perftype',
            'maxRent' => 'Max Rent',
        ];
    }
}
