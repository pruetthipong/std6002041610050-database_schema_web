<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Staff".
 *
 * @property int $id
 * @property string $staffNo
 * @property string $fName
 * @property string $lName
 * @property string $position
 * @property string $sex
 * @property string $DOB
 * @property string $salary
 * @property string $branchNo
 */
class Staff extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Staff';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['staffNo', 'fName', 'lName', 'position', 'sex', 'DOB', 'salary', 'branchNo'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'staffNo' => 'Staff No',
            'fName' => 'F Name',
            'lName' => 'L Name',
            'position' => 'Position',
            'sex' => 'Sex',
            'DOB' => 'Dob',
            'salary' => 'Salary',
            'branchNo' => 'Branch No',
        ];
    }
}
