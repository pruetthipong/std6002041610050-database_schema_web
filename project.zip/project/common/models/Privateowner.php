<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "Privateowner".
 *
 * @property int $id
 * @property string $ownerNo
 * @property string $fname
 * @property string $lname
 * @property string $address
 * @property string $telNo
 */
class Privateowner extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Privateowner';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ownerNo', 'fname', 'lname', 'address', 'telNo'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'ownerNo' => 'Owner No',
            'fname' => 'Fname',
            'lname' => 'Lname',
            'address' => 'Address',
            'telNo' => 'Tel No',
        ];
    }
}
